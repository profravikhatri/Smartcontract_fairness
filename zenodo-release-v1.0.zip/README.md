
# Integrated Smart Contract Optimization (v1.0)

Associated Paper:
Rethinking Smart Contracts: A Human-Centered Approach to Cost, Security, and Fairness

Release Date: 2026-02-28

## Objectives
Multi-objective optimization of:
- Gas cost (G)
- Vulnerability exposure (V)
- Role-based fairness variance (F)

## Dataset
8,000 Ethereum contracts (Nov 2025 snapshot)

## Key Results
- 43.7% average gas reduction
- 0.90 F1 vulnerability detection
- 31% fairness variance reduction
- Runtime ≈ 63ms

## Reproduction

### Solidity
npm install
npx hardhat compile
npx hardhat run scripts/deploy.js

### Python
pip install -r reproducibility/requirements.txt
python code/analysis/correlation_analysis.py

License: MIT
