
# Manifest

This archive contains:
- Full source code structure
- Dataset snapshot
- Experimental configuration
- Reproducibility environment details

All experiments reproducible under standard hardware within 2 hours.
